<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="./style.css">

    <?php $title = "homepage"?>

    <title><?php echo $title;?></title>
    <?php wp_head(); ?>

</head>
<body>
  <header>
               
     <img class="logo" src="<?php echo esc_url( get_template_directory_uri() . '/images/logo-project.png' ); ?>" alt="">

    <input type="checkbox" id="hamburger-bar">
    <label class="hamburger-to-right" for="hamburger-bar" id="hamburger-menu">Menu</label>
    <div>
         <div>
            <?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>
        </div>
       



    </div>



</header>  
<div>


</div>

    <div class="tvv-animatie">
    <h1><span id="element"></span></h1>

<!-- Load library from the CDN -->
<script src="https://unpkg.com/typed.js@2.0.16/dist/typed.umd.js"></script>

<!-- Setup and start animation! -->
<script>
    var typed = new Typed('#element', {
      strings: ['<i>The Vicious Vultures.</i>'],
      typeSpeed: 50,
      backSpeed: 50,
      loop: true
    });
</script>
</div>
</body>
</html>