<?php /* Template Name: team-lid */ ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="./style.css">

    <?php $title = "team lid"?>

    <title><?php echo $title;?></title>
    <?php wp_head(); ?>

</head>
<body>
  <header>
               
     <img class="logo" src="<?php echo esc_url( get_template_directory_uri() . '/images/logo-project.png' ); ?>" alt="">


    <input type="checkbox" id="hamburger-bar">
    <label class="hamburger-to-right" for="hamburger-bar" id="hamburger-menu">Menu</label>
    <div>
         <div>
            <?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>
        </div>
       
    </div>

</header>  
<?php echo get_the_content(); ?>


</body>